<?php 
/*
Plugin Name: Erphpdown集成mycred插件
Plugin URI: http://www.mobantu.com
Description: 在会员推广下载专业版的基础上集成mycred积分插件，运行此插件需要先安装会员推广下载专业版与mycred插件。
Version: 1.0
Author: 模板兔
Author URI: http://www.mobantu.com
*/
define("erphpdown-mycred",plugin_dir_url( __FILE__ ));
?>
