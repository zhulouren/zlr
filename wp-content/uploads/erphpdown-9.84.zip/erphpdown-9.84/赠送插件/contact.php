搭建类型:
[Project]

联系人:
[your-name] 

公司名:
[company] 

邮箱:
[your-email] 

电话:
[your-phone] 

其他联系方式:
[other-contact] 

公司网址:
[your-website] 

搭建面积:
[sqm] 

展会名或项目名:
[event-name] 

预算:
[budget] 

其他设计要求:
[your-message] 