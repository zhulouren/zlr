<?php
/* *
 * by mobantu
*/
require_once('../../../../../wp-config.php');
require_once("class.php");
global $wpdb;
$payjs = new Payjs();
$data = ["return_code" => $_POST['return_code'], "total_fee" => $_POST['total_fee'], "out_trade_no" => $_POST['out_trade_no'], "payjs_order_id" => $_POST['payjs_order_id'], "transaction_id" => $_POST['transaction_id'], "time_end" => $_POST['time_end'], "openid" => $_POST['openid'], "attach" => $_POST['attach'], "mchid" => $_POST['mchid']];
if($payjs->sign($data) == $_POST['sign'] && $_POST['return_code'] == '1'){

	$total_fee=$_POST['total_fee']/100;
	$money_info=$wpdb->get_row("select * from ".$wpdb->icemoney." where ice_num='".$wpdb->escape($_POST['out_trade_no'])."'");
	if($money_info){
		if(!$money_info->ice_success){
			$epd_game_price  = get_option('epd_game_price');
				if($epd_game_price){
					$cnt = count($epd_game_price['buy']);
					for($i=0; $i<$cnt;$i++){
						if($total_fee == $epd_game_price['buy'][$i]){
							$total_fee = $epd_game_price['get'][$i];
						}
					}
				}
			addUserMoney($money_info->ice_user_id, $total_fee*get_option('ice_proportion_alipay'));
			$wpdb->query("UPDATE $wpdb->icemoney SET ice_money = '".$total_fee*get_option('ice_proportion_alipay')."', ice_alipay = '".$wpdb->escape($_POST['payjs_order_id'])."',ice_success=1, ice_success_time = '".date("Y-m-d H:i:s")."' WHERE ice_num = '".$wpdb->escape($_POST['out_trade_no'])."'");
			
		}
	}
}